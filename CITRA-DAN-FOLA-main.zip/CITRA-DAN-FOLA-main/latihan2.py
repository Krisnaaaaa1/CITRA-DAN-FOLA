print("hello merte anjing")
x = 7
y = 3
z = x + y
print ("hasil dari oprasi adalah",y)

dic= {"nama jleme": "merte pepe",
 "asal": "munti",
 "belajar":"metatuk"
}

print(dic["nama jleme"])

def 